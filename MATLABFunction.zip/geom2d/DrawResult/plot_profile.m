clear all;
close all;
clc;

[filename_prolith,pathname_prolith,FilterIndex] = uigetfile(fullfile('D:\Frederick_liguohua\ACO_MATLAB\cases\WINBOND\Results\20150814_OK\','*.pl2'));
if filename_prolith==0
  return;
end

% [filename_CS,pathname_CS,FilterIndex] = uigetfile(fullfile('D:\Frederick_liguohua\ACO_MATLAB\cases\WINBOND\','*.mat'));
% if filename_CS==0
%   return;
% end

folder_work = pathname_prolith;

MyApplication = actxserver('prolith.application');
MyDatabase = invoke(MyApplication, 'Database');
MyDefDoc = invoke(MyApplication, 'ActiveDocument');
MyDocument = MyDefDoc.get('Open', fullfile(pathname_prolith,filename_prolith));
MySimEngine = invoke(MyDocument, 'SimulationEngine');
MyImgSystem = invoke(MyDocument, 'GetImagingSystem', 1);
myMask = invoke(MyDocument, 'GetMask', 1);

KPIdata.profile = invoke(MySimEngine, 'GetMetrologyPlaneSingleRunResult', 'Z', 44);

invoke(MyDocument, 'Close');  

release(MySimEngine);
release(MyDocument);
release(MyApplication); 
  
clear MySimEngine
clear MyDocument
clear MyApplication

profile_data = KPIdata.profile;
n_profile_contour = length(profile_data)-1;

Box_profile = [0 1605 0 2300];
%% ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
h_contour = figure('Position',[1,1,750.0,570.0],'Color',[1 1 1]);
set(h_contour,'InvertHardcopy','on');

ax_contour = axes('Parent',h_contour,'FontSize',12,'FontName','tahoma',...
  'Position',[0.0813 0.0941 0.9026 0.8142]);
axis(ax_contour,'equal')
axis(ax_contour,Box_profile);

ylabel({'Y (nm)'});
xlabel({'X (nm)'});
% set(gca,'Color',[0 0 1]);

hold on

profile_polygon = [];
for iprofile = 1:n_profile_contour
  close_polygon = [profile_data{iprofile+1,1}';profile_data{iprofile+1,1}(:,1)'];
  profile_polygon  = [close_polygon];
  drawPolygon(profile_polygon(:,1),profile_polygon(:,2),'b');
end

hold off

xlim([-850 850]);
ylim([-2100 2100]);
box on;
