% clear all;
% close all;
% clc;

level = 100; n = ceil(level/2);
cmap1 = [linspace(0, 1, n); linspace(0, 1, n); linspace(1, 1, n)]';
cmap2 = [linspace(1, 1, n); linspace(1, 0, n); linspace(1, 0, n)]';
cmap = [cmap1; cmap2(2:end, :)];

[FileName,PathName,FilterIndex] = uigetfile(fullfile('D:\01-Experiment\04-SMO\ACO\FD\193nm\Source_Code\contacthole_03\05\EL_DOF','*.txt'),'MultiSelect','on');

if iscell(FileName)
    nbfiles = length(FileName);
elseif FileName ~= 0
    FileName = {FileName};
    nbfiles = 1;
else
    nbfiles = 0;
    return;
end

h = figure(1);
set(h,'Position',[1,2,585.0,510.0],'Color',[1 1 1]);

axes1 = axes('Parent',h,...
  'Position',[0.0908042658042662 0.0897107495480461 0.777747747747757 0.831857877902934],...
  'PlotBoxAspectRatio',[1 1 1],...
  'Layer','top',...
  'FontSize',12,...
  'FontName','Arial');

hold(axes1,'on');

colormap(jet);

% title_name={'Freeform Shape'};

for ifiles=1:nbfiles
data = importdata(fullfile(PathName,FileName{ifiles}));
source_data = data.data;

x = -1:(1-(-1))/(length(source_data)-1):1;
y = -1:(1-(-1))/(length(source_data)-1):1;

contourf(x,y,source_data,'LineStyle','none','LevelStep',0.001);
axis(axes1,'square');
% xlabel({'X Pupil Position'});
% ylabel({'Y Pupil Position'});
% title({[title_name{ifiles}]},'FontWeight','bold','FontSize',14);

colorbar('peer',axes1,...
  'Position',[0.883098483098488 0.0766930885829508 0.045045045045045 0.869976359338061],...
  'FontSize',12,...
  'FontName','Arial');

set(h,'PaperPositionMode','auto') 
% print('-dtiff','-r300',fullfile(PathName,title_name{ifiles}))
end