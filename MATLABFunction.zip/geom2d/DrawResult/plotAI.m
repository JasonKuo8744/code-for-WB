function plotAI

clc

[FileName,PathName,FilterIndex] = uigetfile(fullfile('D:\01-Experiment\04-SMO\ACO\FD\193nm\Source_Code\contacthole_03\05\EL_DOF','*.txt'),'MultiSelect','on');

if iscell(FileName)
    nbfiles = length(FileName);
elseif FileName ~= 0
    FileName = {FileName};
    nbfiles = 1;
else
    nbfiles = 0;
    return;
end

for ifiles=1:nbfiles
    
    data_aerialimage = importdata(fullfile(PathName,FileName{ifiles}));
    figure(ifiles);
    imagesc(data_aerialimage.data);
    
    %   titlename = [title_name{ifiles}, ' - Aerial Image'];
    
    %   contour(x,y,data_aerialimage.data,'LineStyle','none','LineColor',[0 0 0],...
    %     'LevelStep',0.001,'Fill','on',...
    %     'Parent',axes1);
    %     title({titlename},'FontWeight','bold','FontSize',12);
    %   caxis([0 0.3347])
    %   colorbar('peer',axes1,'FontSize',12,'FontName','Arial');
    
    %   set(h,'PaperPositionMode','auto') ;
    %   print('-dtiff','-r300',fullfile(PathName,titlename));
    % end


    xlabel('X (Pixel)','FontSize',14);
    ylabel('Y (Pixel)','FontSize',14);
    
    axis image;
    axis xy;
    colorbar;
    colormap(jet);



siz = size(data_aerialimage.data);

gcf
% ans.Position = [650 200 siz(2)*2.1 siz(1)*1.5];
% ans.Resize = 'off';
end

end