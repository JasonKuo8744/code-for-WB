
% close all;
% clear all;
% clc;

[FileName,PathName,FilterIndex] = uigetfile(fullfile('D:\01-Experiment\04-SMO\ACO\FD\193nm\Source_Code\contacthole_03\05\EL_DOF','*.txt'),'MultiSelect','on');

if iscell(FileName)
    nbfiles = length(FileName);
elseif FileName ~= 0
    FileName = {FileName};
    nbfiles = 1;
else
    nbfiles = 0;
    return;
end



% title_name={'Aerial Image'};
% title_name={'Conventional','Annular','Quasar','Dipole'};
% title_name = {'ACO Source Ant 1 Iteration 1','ACO Source Ant 2 Iteration 1','ACO Source Ant 3 Iteration 1',...
%   'ACO Source Ant 1 Iteration 2','ACO Source Ant 2 Iteration 2','ACO Source Ant 3 Iteration 2',...
%   'ACO Source Ant 1 Iteration 3','ACO Source Ant 2 Iteration 3','ACO Source Ant 3 Iteration 3',...
%   'ACO Source Ant 1 Iteration 4','ACO Source Ant 2 Iteration 4','ACO Source Ant 3 Iteration 4',...
%   'ACO Source Ant 1 Iteration 5','ACO Source Ant 2 Iteration 5','ACO Source Ant 3 Iteration 5',...
%   'ACO Source Ant 1 Iteration 6','ACO Source Ant 2 Iteration 6','ACO Source Ant 3 Iteration 6',...
%   'ACO Source Ant 1 Iteration 7','ACO Source Ant 2 Iteration 7','ACO Source Ant 3 Iteration 7',...
%   'ACO Source Ant 1 Iteration 8','ACO Source Ant 2 Iteration 8','ACO Source Ant 3 Iteration 8',...
%   'ACO Source Ant 1 Iteration 9','ACO Source Ant 2 Iteration 9','ACO Source Ant 3 Iteration 9',...
%   'ACO Source Ant 1 Iteration 10','ACO Source Ant 2 Iteration 10','ACO Source Ant 3 Iteration 10'};

for ifiles=1:nbfiles
  data_aerialimage = importdata(fullfile(PathName,FileName{ifiles}));
  
  maskregioninsdex1 = strfind(data_aerialimage.textdata,'Parameters');
  maskregioninsdex2 = find(not(cellfun('isempty', maskregioninsdex1)));
  
  region = regexp(data_aerialimage.textdata{maskregioninsdex2+3}, ' ', 'split');
  flag = ~isnan(str2double(region));
  Xsimregion = str2double(region(flag==1));
  region = regexp(data_aerialimage.textdata{maskregioninsdex2+5}, ' ', 'split');
  flag = ~isnan(str2double(region));
  Ysimregion = str2double(region(flag==1));
  
  X_min = Xsimregion(1);
  X_max = Xsimregion(2);
  Y_min = Ysimregion(1);
  Y_max = Ysimregion(2);
  
  x = (X_min:(X_max-X_min)/(size(data_aerialimage.data,2)-1):X_max);
  y = (Y_min:(Y_max-Y_min)/(size(data_aerialimage.data,1)-1):Y_max);

  h = figure('visible','on');
  set(h,'Position',[1,1,626.0,557.0],'Color',[1 1 1]);


  axes1 = axes('Parent',h,...
    'Layer','top',...
    'FontSize',12,...
    'FontName','Arial');
  axis equal;
  colormap(jet);
  titlename = ['Aerial Image'];
  
  contour(x,y,data_aerialimage.data,'LineStyle','none','LineColor',[0 0 0],...
    'LevelStep',0.001,'Fill','on',...
    'Parent',axes1);
  xlabel('nm','FontSize',16);
  ylabel('nm','FontSize',16);
  title({titlename},'FontWeight','bold','FontSize',16);
%   caxis([0 0.3347])
  colorbar('peer',axes1,'FontSize',12,'FontName','Arial');
  xlim([X_min X_max]);
  ylim([Y_min Y_max]);

  set(h,'PaperPositionMode','auto') ;
%   print('-dtiff','-r300',fullfile(PathName,titlename));
% end
  axis image
end

