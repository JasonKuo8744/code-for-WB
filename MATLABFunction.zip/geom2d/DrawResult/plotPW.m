function plotPW
    close all;
    clc;

% level = 100; n = ceil(level/2);
% cmap1 = [linspace(0, 1, n); linspace(0, 1, n); linspace(1, 1, n)]';
% cmap2 = [linspace(1, 1, n); linspace(1, 0, n); linspace(1, 0, n)]';
% cmap = [cmap1; cmap2(2:end, :)];

% X_min = -50;
% X_max = 1600;
% Y_min = 50;
% Y_max = 1300;

    [FileName,PathName,~] = uigetfile(fullfile('D:\01-Experiment\04-SMO\ACO\FD\193nm\02-RESULT\05\part_2\processwindow_OPC\','*.txt'),'MultiSelect','on');

    if iscell(FileName)
        nbfiles = length(FileName);
    elseif FileName ~= 0
        FileName = {FileName};
        nbfiles = 1;
    else
        nbfiles = 0;
        return;
    end

    hold all

    for ifiles = 1:nbfiles
      filedata = fullfile(PathName,FileName{ifiles});
      [~,filename,~] = fileparts(filedata);
      delimiterIn = '\t';
      headerlinesIn = 11;
      imported_data = importdata(filedata,delimiterIn,headerlinesIn);
      data_processwindow = imported_data.data;
    %   ndata = size(data_processwindow,2)/2;
      X = data_processwindow(:,1)*1000;
      Y = data_processwindow(:,2);
      plot(X,Y,'-o','MarkerSize',3,'DisplayName',filename);
    end
    
%     legend('show');
%     legend('IMLDE','MLDE','PROLITHOP');
    
    for ifiles = 1:nbfiles
      filedata = fullfile(PathName,FileName{ifiles});
    %   [pathstr,filename,ext] = fileparts(filedata);
      delimiterIn = '\t';
      headerlinesIn = 11;
      imported_data = importdata(filedata,delimiterIn,headerlinesIn);
      data_processwindow = imported_data.data;
    %   ndata = size(data_processwindow,2)/2;
      X = data_processwindow(:,3)*1000;
      Y = data_processwindow(:,4);
      plot(X,Y,'r');
    end

    hold off

    box;
    axis square;
    % title('Exposure Latitude vs. DOF','FontWeight','bold','FontSize',14);
    xlabel('DOF(nm)','FontSize',12);
    ylabel('Exposure Latitude(%)','FontSize',12);
    gcf
    ans.Position = [600 350 600 500];
    ans.Resize ='off';
    
end
