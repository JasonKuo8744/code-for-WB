clear all;
close all;
clc;

level = 100; n = ceil(level/2);
cmap1 = [linspace(0, 1, n); linspace(0, 1, n); linspace(1, 1, n)]';
cmap2 = [linspace(1, 1, n); linspace(1, 0, n); linspace(1, 0, n)]';
cmap = [cmap1; cmap2(2:end, :)];

X_min = -50;
X_max = 1600;
Y_min = 50;
Y_max = 1300;

[FileName,PathName,FilterIndex] = uigetfile(fullfile('D:\01-Experiment\04-SMO\ACO\FD\193nm\02-RESULT\05\part_2\processwindow_OPC\','*.txt'),'MultiSelect','on');

if iscell(FileName)
    nbfiles = length(FileName);
elseif FileName ~= 0
    FileName = {FileName};
    nbfiles = 1;
else
    nbfiles = 0;
    return;
end

h = figure(1);
markers = ['+','o','*','.','x','s','d','^','v','>','<','p','h'];
set(h,'Position',[1,1,564,415],'Color',[1 1 1]);

axes1 = axes('Parent',h,...
  'Position',[0.0980762800867997 0.118072289156626 0.674973365303271 0.796925570318139],...
  'Layer','top',...
  'FontSize',12,...
  'FontName','Arial');

cmaps = colormap(vivid('osmgvb',[0.8 0.2]));
title_legend = {'ACO FF','ACO DIP'};

hold all
for ifiles = 1:nbfiles
  filedata = fullfile(PathName,FileName{ifiles});
  [pathstr,filename,ext] = fileparts(filedata);
  delimiterIn = '\t';
  headerlinesIn = 11;
  imported_data = importdata(filedata,delimiterIn,headerlinesIn);
  data_processwindow = imported_data.data;
  ndata = size(data_processwindow,2)/2;
  X = data_processwindow(:,1)*1000;
  Y = data_processwindow(:,2);
  plot(X,Y,'LineStyle','--','MarkerFaceColor',[1 1 1],'Marker',markers(ifiles),'MarkerSize',3);
end
hold off

set(axes1, 'color', [1 1 1]);
title('Exposure Latitude vs. DOF','FontWeight','bold','FontSize',14);
xlabel({'DOF(nm)'});
ylabel({'EL(%)'});

legend1 = legend(axes1,'show');
set(legend1,...
  'Position',[0.764775413711583 0.657831325301207 0.221631205673759 0.0610441767068273],'String',title_legend);
legend boxon

set(h,'PaperPositionMode','auto');
% print('-dtiff','-r300',fullfile(pathstr,filename));