function plotmask
% clear all;
close all;
clc;

[filename_prolith,pathname_prolith,~] = uigetfile(fullfile('D:\Frederick_liguohua\ACO_MATLAB\cases\WINBOND\Results\20150814_OK\','*.MSK'));
if filename_prolith == 0
    return
end
filename_prolith = fullfile(pathname_prolith,filename_prolith);

MSK_data = Import_MSK(filename_prolith);
%%
new_MSK_data = MSK_data;

n_MSKdata = length(MSK_data);
index_poly1 = strfind(MSK_data,'Polygon');
index_poly2 = find(not(cellfun('isempty', index_poly1)));
maskregioninsdex1 = strfind(MSK_data,'Parameters');
maskregioninsdex2 = find(not(cellfun('isempty', maskregioninsdex1)));


n_poly = length(index_poly2);

for ipoly = 1:n_poly-1
  text_pos = MSK_data(index_poly2(ipoly)+2:index_poly2(ipoly+1)-2);
  splitvalue = regexp(text_pos, ',', 'split');
  pos_value = str2double(vertcat(splitvalue{:}));
%   sort_posvalue = sortrows(pos_value,1);
  poly_xy(ipoly) = {pos_value};
%   first_value(ipoly) = sort_posvalue(1,1);
end

text_pos = MSK_data(index_poly2(ipoly+1)+2:n_MSKdata-1);
splitvalue = regexp(text_pos, ',', 'split');
pos_value = str2double(vertcat(splitvalue{:}));
% sort_posvalue = sortrows(pos_value,1);
poly_xy(ipoly+1) = {pos_value};
% first_value(ipoly+1) = sort_posvalue(1,1);
% [sort_firstvalue, index_firstvalue] = sort(first_value);
% poly_xy = poly_xy(index_firstvalue);
drawPolygon(poly_xy,'k');

gca;
ans.FontSize = 8;

axis equal;

ylabel('Y (nm)','FontSize',12);
xlabel('X (nm)','FontSize',12);

region = MSK_data(maskregioninsdex2+3);
region = regexp(region, ';', 'split');
maskregion = regexp(region{1,1}, ',', 'split');
maskregion = str2double(maskregion{1,1});

ymax = maskregion(1);
xmax = maskregion(2);
ymin = maskregion(3);
xmin = maskregion(4);

xlim([xmin xmax]);
ylim([ymin ymax]);

gcf;
ans.Position = [650 200 xmax/3.3 ymax/3.3];
ans.Resize = 'off';
Fontsize = 10;
box on;

end

