function plot_processwindow
clc;

level = 100; n = ceil(level/2);
cmap1 = [linspace(0, 1, n); linspace(0, 1, n); linspace(1, 1, n)]';
cmap2 = [linspace(1, 1, n); linspace(1, 0, n); linspace(1, 0, n)]';
cmap = [cmap1; cmap2(2:end, :)];

[FileName,PathName,FilterIndex] = uigetfile(fullfile('D:\01-Experiment\04-SMO\ACO\FD\193nm\New_Source_Code\','*.txt'));

if FileName==0
  return;
end

filedata = fullfile(PathName,FileName);
[pathstr,filename,ext] = fileparts(filedata);

imported_data = importdata(filedata);
data_processwindow = imported_data.data;

ndata = size(data_processwindow,2)/2;

h = figure(1);
set(h,'Position',[1,1,594.0,456.0],'Color',[1 1 1]);
set(h,'PaperPositionMode','auto');

axes1 = axes('Parent',h,...
  'Position',[0.032454518524458735 0.12502409870830908 0.7759233780887317 0.8120279217541531],...
  'PlotBoxAspectRatio',[1 1 1],...
  'Layer','top',...
  'FontSize',12,...
  'FontName','Arial');

cmaps = colormap(vivid('osmgvb',[0.8 0.2]));
index_1 = length(cmaps);

set(axes1, 'color', [1 1 1]);
% title_ax=title('Process Window - BF=0.0nm, DOF=316nm @ EL=5.0%','FontWeight','bold','FontSize',14);
xlabel({'Focus(nm)'});
ylabel({'1/Threshold'});


X_min = Inf;
Y_min = Inf;
X_max = -Inf;
Y_max = -Inf;

title_legend = regexp(imported_data.textdata(9), '- CD', 'split');
title_legend = title_legend{1,1};

hold(axes1,'on');

for idata = 1:ndata-3
  X = data_processwindow(:,(idata*2)-1)*1000;
  Y = data_processwindow(:,(idata*2));
  
  line(X,Y,'LineStyle','-.','LineWidth',2,'Color',cmaps(mod(idata*33,index_1),:),'Parent',axes1);
  
  X_min = min([X;X_min]);
  Y_min = min([Y;Y_min]);
  Y_max = max([Y;Y_max]);
  X_max = max([X;X_max]);
end

X = data_processwindow(:,(idata+1)*2-1)*1000;
Y = data_processwindow(:,(idata+1)*2);
line(X,Y,'LineWidth',2.5,'Color','b','Parent',axes1);

X_min = min([X;X_min]);
Y_min = min([Y;Y_min]);
Y_max = max([Y;Y_max]);
X_max = max([X;X_max]);
  
X = data_processwindow(:,(idata+2)*2-1)*1000;
Y = data_processwindow(:,(idata+2)*2);
X = [X;X(1)];
Y = [Y;Y(1)];
line(X,Y,'LineWidth',1,'Color','r','Parent',axes1);

X_min = min([X;X_min]);
Y_min = min([Y;Y_min]);
Y_max = max([Y;Y_max]);
X_max = max([X;X_max]);

hold all;
X = data_processwindow(:,(idata+3)*2-1)*1000;
Y = data_processwindow(:,(idata+3)*2);
scatter(axes1,X,Y,8,'b','filled');
hold off;

axis([X_min X_max Y_min Y_max]);

legend1 = legend(axes1,'show');
set(legend1,...
  'Position',[0.779749636195669 0.450003399972799 0.21043771043771 0.282163742690058],'String',title_legend);
legend boxoff 
box

% pos = get(axes1, 'OuterPosition');
% 
% set (title_ax, 'position', [pos(1) + pos(3)/2, ...
%      pos(2) - 0.01] )
% set(title_ax,'HorizontalAlignment', 'center');
hold(axes1,'off');
% latexPackages = ['\usepackage{charter}\n \renewcommand{\sfdefault}{bch}\n \renewcommand{\rmdefault}{bch}'];
% latexfigure(h,'latexfigure','png','packages', latexPackages); % 'mathmode', false, 'debug', true

% pos = get(axes1, 'OuterPosition');
% print('-dtiff','-r300',fullfile(pathstr,filename));
end