%% DE 
plot(BestCost1)
hold on
plot(BestCost2)
xlabel('Iteration','FontSize',12);
ylabel('Fitness','FontSize',12);
legend('IMLDEO','MLDE');

%% SA
plot(Cost1)
hold on
plot(Cost2)
xlabel('Iteration','FontSize',12);
ylabel('Fitness','FontSize',12);
legend('IMLDEO','MLDE');
