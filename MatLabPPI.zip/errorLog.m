function errorLog(commandName, errNum, errMessage)
%   Logging
%   Write error message to log file
%   commandName as string, errNum as int, errMessage as string

global MPPI_FILEID
global MPPI_LOGLEVEL
global MPPI_MULTIPASS

str1 = 'An error occured -';

switch errNum
    case 0 
        str1 = strcat(str1,'Not enough or too many input arguments for -  ');
        str = strcat(str1,commandName,' command,',' Please check the number of arguments. \n');
    case 1
        str = strcat(str1,commandName,' command -- ', errMessage);
    case 2
        str = strcat(str1,'Not a vaild parameter name. Please double check the parameter. \n');
    case 3
        str = strcat(str1,'Not a vaild parameter number. Please double check the number. \n');
    case 4
        str = strcat(str1,'Do not have Yield Analyzer Liciense or Need run a Simulation set simulation first. \n');
    case 5
        str = strcat(str1,' Need enter YieldAnalyzerMode. Or does not have Yield Analyzer Liciense or Need run a Simulation set simulation first. \n');   
    case 6
        str = strcat(str1,commandName,' command -- ',' Need run runYieldAnalyzerFrequency first.\n');
        %otherwise
end
 
     
if  MPPI_FILEID ~= -1
    if isempty(MPPI_FILEID) == 0 & MPPI_LOGLEVEL >1
        fprintf(MPPI_FILEID,str);
        fclose(MPPI_FILEID);
        MPPI_FILEID = -1;
    end
end

% report error
error(str);
