function loadDocument(fileName)
%   Loads a specified .pl2 or .plt document. This command load and sets the file as the 
%   default(active)document
%   Function requires 1 argument - fileName as string

global MPPI_PROLITH
global MPPI_PROLITHDOCUMENT
global MPPI_PROLITHSIMENGINE
global MPPI_FILEID
global MPPI_LOGLEVEL


if nargin ~= 1
    errorLog('LoadDocument',0,'');
end

try,
    tempDoc = MPPI_PROLITHDOCUMENT;
    MPPI_PROLITHDOCUMENT = invoke(tempDoc, 'Open',fileName);
    MPPI_PROLITHSIMENGINE = MPPI_PROLITHDOCUMENT.SimulationEngine;
    %delete(tempDoc),
catch,
    errorLog('LoadDocument',1,lasterr);
end    

if MPPI_FILEID ~= -1 
    if isempty(MPPI_FILEID) == 0 & MPPI_LOGLEVEL >1
        str = strcat('User loaded .pl2 file -- ',fileName,'\n');
        fprintf(MPPI_FILEID,str);
   end
end


