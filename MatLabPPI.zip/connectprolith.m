function connectprolith()
%   launches and connects PROLITH to the programming environment


global MPPI_PROLITH
global MPPI_PROLITHDOCUMENT
global MPPI_PROLITHSIMENGINE
global MPPI_FILEID
global MPPI_LOGLEVEL

global MPPI_SIM_INPUT_NUM
global MPPI_SIM_OUTPUT_NUM


%   Create a PROLITH activeX automation.
MPPI_PROLITH = actxserver('Prolith.Application');


%   set PROLITH visible (1), or unvisible(0)
set (MPPI_PROLITH, 'Visible',1);

% Get document
MPPI_PROLITHDOCUMENT = MPPI_PROLITH.ActiveDocument;

% Get simulation engine
MPPI_PROLITHSIMENGINE = MPPI_PROLITHDOCUMENT.SimulationEngine;

%   initial all the MPPI_PROLITHCONSTANT
%   ProlithConstantInit;

MPPI_SIM_INPUT_NUM = 0;
MPPI_SIM_OUTPUT_NUM = 0;

if isempty(MPPI_FILEID)
    MPPI_FILEID = -1;
end

if MPPI_FILEID ~= -1 
    if isempty(MPPI_FILEID) == 0 & MPPI_LOGLEVEL > 0
        str = 'User Successfully Connected to PROLITH at: ';
        strtime = datestr(now);
        str = strcat(str,strtime,'\n');
        fprintf(MPPI_FILEID,str);
    end
end


