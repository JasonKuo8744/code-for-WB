function saveDocument(fileName)
%   Save the current document with simulation data to a .pl2 or .plt file 
%   Function requires 1 input arguments -- fileName as string

global MPPI_PROLITHDOCUMENT
global MPPI_FILEID
global MPPI_LOGLEVEL


if nargin ~= 1
    errorLog('SaveDocument',0,'');
end


try,
    invoke(MPPI_PROLITHDOCUMENT,'SaveAs',fileName);
catch,
    errorLog('SaveDocument',1,lasterr);
end

if MPPI_FILEID ~= -1 
    if isempty(MPPI_FILEID) == 0 & MPPI_LOGLEVEL >1
        str = strcat('\nUser Successfully Saved .pl2 document as: ','\b',fileName,'\n');
        fprintf(MPPI_FILEID,str);
    end
end

