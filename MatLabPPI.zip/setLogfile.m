function setLogFile(fileName)
%   Logging
%   Defines the name and path to the log file.
%   you must execute this command before logging can begin. If a log file
%   already exist, this command will overwrites the file
%   Function requires 1 input argument - fileName as string

global MPPI_PROLITHSIMENGINE
global MPPI_FILEID
global MPPI_LOGLEVEL
global MPPI_LOGFILENAME

if nargin ~= 1
    errorLog('SetLogFile',0,'');
end

MPPI_LOGFILENAME = fileName

MPPI_FILEID = fopen(MPPI_LOGFILENAME,'w') 

if MPPI_FILEID ~= -1
    str = strcat('This is the MPPI Log file. ',datestr(date),'\n\n');
    fprintf(MPPI_FILEID,str);
else
    error('Could not open the file');
end


