function logComment(comment)
%   Logging
%   Writes user - specified comments to the log file.
%   Function requires 1 argument - comment as string

global MPPI_FILEID

if MPPI_FILEID ~= -1 
    if isempty(MPPI_FILEID) == 0
        str = strcat(comment,'\n');
        fprintf(MPPI_FILEID,str);
    end
    %else
    %error('no log file has been opened!');
end

