function setLogLevel(levelNum)
%   Logging
%   Set log level. 
%   changes the level of detail for logging
%   3 levels of logging(levelNum are:   0 --- off
%                                       1 --- simulation logging only
%                                       2 --- full logging
%   Function requires 1 input argument - levelNum

global MPPI_PROLITHSIMENGINE
global MPPI_FILEID
global MPPI_LOGLEVEL
global MPPI_LOGFILENAME

if nargin ~= 1 | levelNum > 2 | levelNum < 0
   levelNum = 2;
end

MPPI_LOGLEVEL = levelNum;
str = 'Log level has been set to: ';
str = strcat(str, num2str(levelNum),'\n');


if MPPI_FILEID ~= -1 
    if isempty(MPPI_FILEID) == 0 
        fprintf(MPPI_FILEID,str)
    end
end


