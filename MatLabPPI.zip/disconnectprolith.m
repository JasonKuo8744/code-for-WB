function disconnectProlith()
%  This command closes and exits from PROLITH
%  Clears all PROLITH variables

global MPPI_PROLITH
global MPPI_PROLITHDOCUMENT
global MPPI_PROLITHSIMENGINE
global MPPI_FILEID
global MPPI_LOGLEVEL

release (MPPI_PROLITHSIMENGINE);
clear MPPI_PROLITHSIMENGINE;
release (MPPI_PROLITHDOCUMENT);
clear MPPI_PROLITHDOCUMENT;
release (MPPI_PROLITH);
clear MPPI_PROLITH;

if MPPI_FILEID ~= -1 & MPPI_LOGLEVEL > 0
    str = 'User Successfully Disconnected from PROLITH at: ';
    strtime = datestr(now);
    str = strcat(str,strtime,'\n');
    fprintf(MPPI_FILEID,str);
    fclose(MPPI_FILEID);
end

MPPI_FILEID = -1;