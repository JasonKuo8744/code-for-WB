function outputELvsDOFData(fileName)
%   Write the results of the Exposure Latitude versus Depth of
%   Focus plot to a text file. Same as simulation set output
%   The data is available only if you selected exposure and focus 
%   as input parameters and resist CD as the output parameter.
%   Function requires 1 input arguments --file name as string

global MPPI_PROLITHSIMENGINE
global MPPI_FILEID
global MPPI_LOGLEVEL


if nargin ~= 1
    errorLog('OutputELvsDOFData',0,'');
end

try,
    invoke(MPPI_PROLITHSIMENGINE,'OutputGraphData',fileName,305);
catch,
    errorLog('OutputELvsDOFData',1,lasterr);
end    

if MPPI_FILEID ~= -1 
    if isempty(MPPI_FILEID) == 0 & MPPI_LOGLEVEL >1
        str = strcat('\nOutputELvsDOFData command output data to file: ','\b',fileName,'\n');
        fprintf(MPPI_FILEID,str);
   end
end



